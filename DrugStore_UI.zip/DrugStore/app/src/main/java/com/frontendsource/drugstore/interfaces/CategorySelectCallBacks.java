package com.frontendsource.drugstore.interfaces;

public interface CategorySelectCallBacks {
    void onCategorySelect(int position);
}