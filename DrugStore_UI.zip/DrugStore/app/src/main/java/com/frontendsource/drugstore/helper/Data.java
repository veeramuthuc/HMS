package com.frontendsource.drugstore.helper;

import com.frontendsource.drugstore.model.Offer;

import java.util.ArrayList;
import java.util.List;

public class Data {

    List<Offer> offerList = new ArrayList<>();


    public List<Offer> getOfferList() {


        return offerList;
    }
}
