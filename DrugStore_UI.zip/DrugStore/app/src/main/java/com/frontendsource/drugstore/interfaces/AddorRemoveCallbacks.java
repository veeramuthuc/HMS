package com.frontendsource.drugstore.interfaces;


public interface AddorRemoveCallbacks {

    void onAddProduct();

    void onRemoveProduct();

    void updateTotalPrice();
}