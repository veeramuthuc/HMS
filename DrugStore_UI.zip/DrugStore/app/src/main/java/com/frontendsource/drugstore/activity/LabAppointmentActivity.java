package com.frontendsource.drugstore.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.frontendsource.drugstore.R;

public class LabAppointmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab_appointment);
    }
}